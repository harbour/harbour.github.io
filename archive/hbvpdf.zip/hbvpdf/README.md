Welcome to _pure_ Clipper PDF Library
=====================================

* Changes in Release 0.08

  Fixed page buffer string overflow.

* Changes in Release 0.07a

  Fixed minor errors with JPEG function to work properly with GRAY & RGB.

* Changes in Release 0.07

  Fixed minor errors.

* Changes in Release 0.06

  * Added new function `pdfBox1()` for colorful boxes.
  * Added new page to demo program.

* Changes in Release 0.05

  * Added `#ifdef` - `#endif` for Harbour support.
  * Fixed minor error for allow different page sizes (A4, ...).

* Changes in Release 0.04

  * Added Courier font.
  * `TOP`, `LEFT`, `BOTTOM` changed to `PDFTOP`, `PDFLEFT`, `PDFBOTTOM` to avoid conflicts.
  * Please note 3 most popular fonts now available: Times, Helvetica, Courier. When calling `pdfSetFont()`, please use only above names.

* Changes in Release 0.03

  Replaced function from Clipper Tools and Nanfor for Clipper Source.

* This is first public release 0.02


Please send your comments to
<andvit@sympatico.ca>

Thank you
